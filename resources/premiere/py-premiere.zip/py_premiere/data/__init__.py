"""Static data tables."""
